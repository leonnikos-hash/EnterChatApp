# EnterChatApp (Expo + React Native WebView)

Έτοιμο project για να ανοίγει το **https://enterchat.gr/** ως native εφαρμογή.

## Γρήγορη εκτέλεση (Development)

1. Εγκατάσταση Node.js LTS.
2. Στον φάκελο του project:
   ```bash
   npm install
   npx expo start
   ```
3. Άνοιξε στο κινητό το Expo Go (Android/iOS) και σκάναρε το QR.

## Android / iOS Native Build

- Android:
  ```bash
  npm run android
  ```
  (απαιτεί Android Studio & SDK)

- iOS (σε Mac):
  ```bash
  npm run ios
  ```
  (απαιτεί Xcode)

## Παραγωγή APK/IPA (με EAS)

1. Εγκατάσταση EAS CLI:
   ```bash
   npm install -g eas-cli
   eas login
   eas build:configure
   ```
2. Build:
   ```bash
   npm run build:android
   npm run build:ios
   ```

## Ρυθμίσεις

- Εικονίδιο εφαρμογής: `assets/icon.png`
- Splash screen: `assets/splash.png`
- URL: στο `app.json` > `expo.extra.ENTERCHAT_URL` και στο `App.js` (σταθερά `ENTERCHAT_URL`)

## Σημειώσεις

- Το project χρησιμοποιεί Expo SDK 51 και `react-native-webview`.
- Για επιπλέον δυνατότητες (push notifications, deep links, offline cache) μπορούμε να τις προσθέσουμε.
