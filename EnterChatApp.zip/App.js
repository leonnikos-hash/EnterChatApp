import React, { useRef, useState, useCallback } from 'react';
import { View, ActivityIndicator, RefreshControl, BackHandler, Platform, ToastAndroid } from 'react-native';
import { WebView } from 'react-native-webview';

const ENTERCHAT_URL = 'https://enterchat.gr/';

export default function App() {
  const webRef = useRef(null);
  const [loading, setLoading] = useState(true);
  const [canGoBack, setCanGoBack] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  const onAndroidBackPress = useCallback(() => {
    if (canGoBack && webRef.current) {
      webRef.current.goBack();
      return true;
    }
    // double-tap to exit
    if (Platform.OS === 'android') {
      ToastAndroid.show('Πατήστε πάλι Πίσω για έξοδο', ToastAndroid.SHORT);
    }
    return false;
  }, [canGoBack]);

  React.useEffect(() => {
    if (Platform.OS === 'android') {
      const sub = BackHandler.addEventListener('hardwareBackPress', onAndroidBackPress);
      return () => sub.remove();
    }
  }, [onAndroidBackPress]);

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    webRef.current?.reload();
    setTimeout(() => setRefreshing(false), 800);
  }, []);

  return (
    <View style={{ flex: 1, backgroundColor: '#0a1738' }}>
      <WebView
        ref={webRef}
        source={{ uri: ENTERCHAT_URL }}
        originWhitelist={['*']}
        javaScriptEnabled
        domStorageEnabled
        onLoadStart={() => setLoading(true)}
        onLoadEnd={() => setLoading(false)}
        onNavigationStateChange={(navState) => setCanGoBack(navState.canGoBack)}
        pullToRefreshEnabled
        startInLoadingState
        renderLoading={() => (
          <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
            <ActivityIndicator size="large" />
          </View>
        )}
      />
      {loading && (
        <View style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 3, backgroundColor: '#ffffff33' }} />
      )}
    </View>
  );
}
